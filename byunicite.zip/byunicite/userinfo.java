/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package byunicite;

import java.io.Serializable;

/**
 *
 * @author 96656
 */
public class userinfo implements Serializable {
    private String name ;
    private String PhoneNumber ;
    private String email ;
    private String City ;
    private String PsotCode ;
    private String event ;

    public userinfo(String flyname, String flyclass, double flyprice) {
        this.flyname = flyname;
        this.flyclass = flyclass;
        this.flyprice = flyprice;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public String getFlyname() {
        return flyname;
    }

    public void setFlyname(String flyname) {
        this.flyname = flyname;
    }

    public String getFlyclass() {
        return flyclass;
    }

    public void setFlyclass(String flyclass) {
        this.flyclass = flyclass;
    }

    public double getFlyprice() {
        return flyprice;
    }

    public void setFlyprice(double flyprice) {
        this.flyprice = flyprice;
    }
    private String flyname ;
    private String flyclass ;
    private double flyprice ;
    

    public userinfo(String name, String PhoneNumber, String email, String City, String PsotCode) {
        this.name = name;
        this.PhoneNumber = PhoneNumber;
        this.email = email;
        this.City = City;
        this.PsotCode = PsotCode;
        
    }

    public String getName() {
        return name;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public String getCity() {
        return City;
    }

    public String getPsotCode() {
        return PsotCode;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPhoneNumber(String PhoneNumber) {
        this.PhoneNumber = PhoneNumber;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setCity(String City) {
        this.City = City;
    }

    public void setPsotCode(String PsotCode) {
        this.PsotCode = PsotCode;
    }

    @Override
    public String toString() {
        return name + " " + PhoneNumber + " " + email + " " + City + " " + PsotCode;
    }
    
}
