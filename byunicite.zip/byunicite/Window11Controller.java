/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package byunicite;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author maram
 */
public class Window11Controller implements Initializable {

    @FXML
    private Menu signout;
    @FXML
    private MenuItem help;
    @FXML
    private CheckBox E2;
    @FXML
    private Button Inovice;
    @FXML
    private Button exit;
    @FXML
    private CheckBox E1;
    @FXML
    private CheckBox E4;
    @FXML
    private CheckBox E3;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void helpActopn(ActionEvent event) {
         // call a joptionPane to help a user 
        JOptionPane.showMessageDialog(null, "To contact wit us Instagram: Alula.moment |  Number:0543959409 ", "Help", JOptionPane.INFORMATION_MESSAGE);
   
    }

    @FXML
    private void SignoutAction(ActionEvent event) {
    }

    @FXML
    private void InoviceAction(ActionEvent event) {
        StringBuilder invoiceBuilder = new StringBuilder();
    double total = 0.0;
    
    if (E1.isSelected()) {
        // Add information for event E1
        invoiceBuilder.append("ANCIENT TINGDOMS FESTIVAL:\n");
        invoiceBuilder.append("Description: \n"
                +"During the Ancient Kingdoms Festival, the three great oases of northwest Arabia - AlUla, \n"
                +"Khaybar and Tayma - welcomed visitors from across the world for an unprecedented experience \n"
                +"of history that spans millennia. \n"); // Add the description of event E1
        invoiceBuilder.append("\n");
        invoiceBuilder.append("Price: 200\n\n"); // Add the price of event E1
        total += 200; // Update the total price
    }

    if (E2.isSelected()) {
        // Add information for event E2
        invoiceBuilder.append("WINTER TANTORA:\n");
        invoiceBuilder.append("Description: Winter at Tantora Festival is a seasonal event held \n "
                +"every year in the rocky desert town of Al-Ula, located in northwest Sudi Arabia,\n "
                +"Tourists participate in Tantora Festival with lots of enthusiasm and exitement \n"); // Add the description of event E2
        invoiceBuilder.append("\n");
        invoiceBuilder.append("Price: 220\n\n"); // Add the price of event E2
        total += 220; // Update the total price
    }
    
    if (E3.isSelected()) {
        // Add information for event E3
        invoiceBuilder.append("EID AL-ADHA:\n");
        invoiceBuilder.append("Description: Surrounded by breathtakingly beautiful natural landscapes, \n"
                +"captivating history and culture, and unique dining concepts, AlUla is a fascinating \n"
                +"place to spend the Eid AlAdha holiday. From exploring Hegra to challenging yourself at \n "
                +"rock climbing, do something different this Eid.\n"); // Add the description of event E3
        invoiceBuilder.append("\n");
        invoiceBuilder.append("Price: 300\n\n"); // Add the price of event E3
        total += 300; // Update the total price
    }
    
    if (E4.isSelected()) {
        // Add information for event E4
        invoiceBuilder.append("SUMMER IN ALULA:\n");
        invoiceBuilder.append("Description: Summer has always been a special time in AlUla, where locals and \n"
                +"travellers alike found refuge in the lush AlUla Oasis. As the heat rises across the Arabian \n"
                +"Peninsula, AlUla’s verdant oasis bears fruits, gives shade and becomes a place for respite \n"
                +"and relaxation, a gem of the Arabian Peninsula in the summer.\n"); // Add the description of event E4
        invoiceBuilder.append("\n");
        invoiceBuilder.append("Price: 250\n\n"); // Add the price of event E4
        total += 250; // Update the total price
    }
    invoiceBuilder.append("\n");
    // Add additional information or calculations if needed
    // invoiceBuilder.append("Additional Information: ...\n");
    
    // Append the total price to the invoice
    invoiceBuilder.append("Total Price: $" + total);
    
    // Show the invoice to the user
    JOptionPane.showMessageDialog(null, invoiceBuilder.toString(), "Invoice", JOptionPane.INFORMATION_MESSAGE);

    }

    @FXML
    private void exitAction(ActionEvent event) {
         System.exit(0);
    }

    @FXML
    private void eventlist(ActionEvent event) {
    }
    
}