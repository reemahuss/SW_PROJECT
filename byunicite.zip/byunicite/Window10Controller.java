/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package byunicite;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.MenuItem;
import javafx.scene.control.RadioButton;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author 96656
 */
public class Window10Controller implements Initializable {

    private Button ADDTOCART;
    @FXML
    private Button exit;
    @FXML
    private MenuItem SIGNOUT;
    @FXML
    private MenuItem HELP;
    @FXML
    private ComboBox<String> classSA;
    @FXML
    private ComboBox<String> classFly;
    @FXML
    private Button Inovice;

    String FName, Class;
    double price;
    @FXML
    private RadioButton Flynass;
    @FXML
    private RadioButton sa;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        classSA.getItems().addAll(
                "Economy",
                "Business Class",
                "First Class"
        );
        classFly.getItems().addAll(
                "Economy",
                "Business Class",
                "First Class"
        );

    }

    @FXML
    private void exitAction(ActionEvent event) {
        System.exit(0);
    }

    @FXML
    private void sign_out(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("byunicite.fxml"));
            Stage stage = (Stage) ADDTOCART.getScene().getWindow();
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);
            stage.show();

        } catch (IOException io) {
            System.out.println("FXML Loading Error");
        }
    }

    @FXML
    private void help(ActionEvent event) {
         // call a joptionPane to help a user 
        JOptionPane.showMessageDialog(null, "To contact wit us Instagram: Alula.moment |  Number:0543959409 ", "Help", JOptionPane.INFORMATION_MESSAGE);
   
    }

    @FXML
    private void InoviceAction(ActionEvent event) throws IOException{
        
        
        // when press inovice 1- create a file to write the data for all choose
        FileWriter fileWriter = new FileWriter("flight.txt");
        PrintWriter P = new PrintWriter(fileWriter);
        P.println("------Welcome to Alula----");
  
        if (sa.isSelected()) {
            FName = "SaudiAirlines";
            Class = classSA.getValue();
            if(Class==null){
             JOptionPane.showInternalMessageDialog(null, "Invalid !you must choose the Flyigh");
            }
            else if (Class.matches("Economy")) {
                price = 1100;
            } else if (Class.matches("Business Class")) {
                price = 2000;
            } else if (Class.matches("First Class")) {
                price = 3100;
            }
            Byunicite.users.add(new userinfo(FName, Class, price));
            System.out.println(FName + "  --- " + Class + "  --  " + price);
        } else if (Flynass.isSelected()) {
            FName = "Flynass";
            Class = classFly.getValue();
            if (Class.matches("Economy")) {
                price = 800;
            } else if (Class.matches("Business Class")) {
                price = 1200;
            } else if (Class.matches("First Class")) {
                price = 2200;
            }
            Byunicite.users.add(new userinfo(FName, Class, price));
            P.println(FName + "  --- " + Class + "  --  " + price);
            System.out.println(FName + "  --- " + Class + "  --  " + price);
           
        }
 P.close();
 JOptionPane.showMessageDialog(null, "Thank you!\n The total information:\n "+"Name :"+ FName + "\n Class :" +Class +"\n Price :" +price);
        // close applection
        System.exit(0);
    }

    @FXML
    private void ClassAction(ActionEvent event) {
        
    }

    @FXML
    private void flighAction(ActionEvent event) {
        
         if (sa.isSelected() && Flynass.isSelected()) {
            JOptionPane.showMessageDialog(null, "choose one!", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            if (sa.isSelected()) {
            FName = "SaudiAirlines";
            Class = classSA.getValue();
            if(Class==null){
             JOptionPane.showInternalMessageDialog(null, "Invalid !you must choose the Flyigh");
            }
            else if (Class.matches("Economy")) {
                price = 1100;
            } else if (Class.matches("Business Class")) {
                price = 2000;
            } else if (Class.matches("First Class")) {
                price = 3100;
            }
            Byunicite.users.add(new userinfo(FName, Class, price));
            System.out.println(FName + "  --- " + Class + "  --  " + price);
            
            } else if (Flynass.isSelected()) {
            FName = "Flynass";
            Class = classFly.getValue();
            if (Class.matches("Economy")) {
                price = 800;
            } else if (Class.matches("Business Class")) {
                price = 1200;
            } else if (Class.matches("First Class")) {
                price = 2200;
            }
            Byunicite.users.add(new userinfo(FName, Class, price));
        }
    }
}
}