/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package byunicite;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button; 
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author 96656
 */
public class Byunicite extends Application {

    public static ArrayList<userinfo> users;

    @Override
    public void start(Stage stage) {
        try {
            // Load the FXML file.
            Parent parent = FXMLLoader.load(getClass().getResource("byunicite.fxml"));
            // Build the scene graph.
            Scene scene = new Scene(parent);
            // Display our window, using the scene graph.
            stage.setTitle("byunicite");
            stage.setScene(scene);
            stage.show();

        } catch (Exception e) {
            System.out.println("FXML Loading Error");
        }

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        users = new ArrayList<>();
        fetchData();
        launch(args);
    }

    public static void saveData() throws FileNotFoundException {
        PrintWriter p = new PrintWriter("Users.dat");
        for (userinfo b : users) {
            p.println(b.toString());
        }
        p.close();
    }

    public static void fetchData() throws IOException {
        File usersFile = new File("Users.dat");
        if (!usersFile.exists()) {
            usersFile.createNewFile();
        }

        Scanner read = new Scanner(usersFile);
        while (read.hasNext()) {
            String s = read.nextLine();
            String[] strs = s.split(" ");
            users.add(new userinfo(strs[0], strs[1], strs[2], strs[3], strs[4]));
        }
        read.close();
    }
}
